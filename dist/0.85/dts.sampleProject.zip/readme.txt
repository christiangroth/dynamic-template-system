Quickstart:
----------
If you just want to run this project call the execute.bat and it will be exported to directory export.helloWorld.

Abstract:
---------
This helloWorld application tries to provide all information you need to do a quickstart. Primarily because there is not a single piece of
documentation, yet. Here you can take a look at every processing, parameter and generic that is implemented so far. To find all of the generics
be sure to also take a look at the other files that are relevant for content generation.

About themes, pages, parameter, generics and plugins:
-----------------------------------------------------
Just a few words to the basics of DTS. How does it work?
You can generate content base on themes, so you have to define at least one theme. But a theme does not generate anything, it is just a template which you
can use to generate content. Content is generated with pages which will result in files during export and each page is using exactly one theme. So there we are:
a page grabs a theme and generates content ... hmm ... but ... how does this work?? Is it really just that easy?? Yes ... uhm .. nearly. You have to define some
placeholders which values have to be replaces at runtime (otherwise you wouldn't need a template system right??). These placeholders use the following syntax:

	${someName}

So we just need to tell the page which placeholders have to be replaced. To do this we use parameters. The name of the parameter is ... did you get it? Right! It's
the name of the placeholder. Each parameter has a minimum of two attributes (name and type). Depending on the type you have to define more attributes. Just take
a look at the examples in a few minutes. All parameters are registered as plugins before the execution begins.

Beside parameters there are also generics and processing. Generics are kind of "page independent parameters". So you just use them everywhere you want and they
will be processed and replaced after all parameters are processed. In combination with parameters you can use generics inside some parameter values. This is called lazy
loading.

	Generics:
	---------
	Generics can be used to provide more generic and flexible behaviour than parameters, but first of all they are page independent.
	They can also be used in parameter-attributes.
	
	In general generics are replaced after all parameters have ben processed. In case of generics in parameter attributes they
	are processed directly, so the parameter can be evaluated correctly. This is called lazy loading, because the parameter is loaded
	at runtime with all its values.
	
	To use generics just write a placeholder like you would do for a parameter. The name must be the generics plugin-key you provide in the plugins-section in this file.
	But be careful to avoid name-crashes! Additionally some generics are capable of reading parameters and some even need their parameters.
	To provide parameters put a colon (":")  after the name to introduce the parameter-section. If no parameters are used, just close the curly 
	brackets after the name, like you do with parameters. In the parameter-section of a generic you can provide key-value-pairs each separated
	with a comma (","). Key and value are separated with an equality sign ("="). So be sure not to use either a comma or equality sign as part of
	the value.

The last plugin-type is a processing. This is only relevant when using the export-all function of dts. This has three phases:
 - pre-processing
 - export-all
 - post-processing

This is simple, you just provide a processing in pre- or post-section and it will be executed in the corresponding phase. 

HelloWorld-Project:
-------------------
Let's focus on this project now. The directory structure for this project is as follows:

 - dts.sampleProject/export.helloWorld
	- export-directory where are files will be generated. If not existent this one will be created during export
 - dts.sampleProject/lib
	- all needed libraries plus all dts modules are put here
 - dts.sampleProject/sample
	- this is your projects directory. Later more to this one ...
 - dts.sampleProject/src
	- you can put your sources (parameters/processings/generics) here. they will be put to classpath before execution. Nice service eh? :-)
 - dts.sampleProject/build.VERSION
	- just the dts-version
 - dts.sampleProject/configureClasspath.bat
	- changes classpath temporarily before execution
 - dts.sampleProject/execute.bat
	- execute the BatchInvoker. This one exports all pages to export-folder
 - dts.sampleProject/build.xml
	- compiles your sources and puts them into lib
 - dts.sampleProject/log4j.xml
	. log4j settings

When invoking the DTS using the BatchInvoker you have to provide three parameters:
	1) the base-directory
	2) path to your projects dts-xml (this file)
	3) the export-directory
Parameter one and three will be provided for generics, so they can do stuff in this directories.

The project-directory (further called workspace) for this project:
You can organize this directory like you want, but it is a good practice to provide the projects dts-xml in the root of your workspace. It's also a good idea to separate
data for content generation, templates and static ressources. This workspace has the following structure:

 - <workspace>/data
	- everything you need to generate your content
 - <workspace>/static
	- static ressources (these are copied into export-directory during processing)
 - <workspace>/themes
	- all themes are put here 
 - <workspace>/helloWorld.dts.xml
	- your projects dts-xml (this file)

You can do it easier:
---------------------
So before you suck in the rest of this file let me say just one more thing: 
Yes, some things in this helloWorld-Project might be done a little complicated, but this example uses each element (parameter/generic/processing) at least one time, so you can
take a look at the different elements.

Contact:
--------
Feel free to contact me: kontakt@christian-groth.info
Have Fun!